class Odam:
    def __init__(self,Ismi,Balans,card,karmon,phone_number) -> None:
        self.ismi = Ismi
        self.balans = Balans
        self.card = card
        self.karmon = karmon
        self.nomer = phone_number